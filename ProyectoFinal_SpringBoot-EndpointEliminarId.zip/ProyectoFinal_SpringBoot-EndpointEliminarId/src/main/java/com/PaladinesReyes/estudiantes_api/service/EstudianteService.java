package com.PaladinesReyes.estudiantes_api.service;


import com.PaladinesReyes.estudiantes_api.model.Estudiante;
import com.PaladinesReyes.estudiantes_api.repository.EstudianteRepository;
import org.springframework.stereotype.Service;
import com.PaladinesReyes.estudiantes_api.exception.RecursoNoEncontradoException;
import java.util.List;


// despues agregaremos buscarPorId, actualizar y eliminar
@Service
public class EstudianteService {

    private final EstudianteRepository repository;

    public EstudianteService(EstudianteRepository repository) {
        this.repository = repository;
    }

    public List<Estudiante> listarTodos() {
        return repository.findAll();
    }

    public Estudiante guardar(Estudiante estudiante) {
        return repository.save(estudiante);
    }

    //Metodo de buscar por id junto a la excepcion personalizada que lanzara como mensaje "Estudiante con id X no encontrado"
    //en caso de que el id no exista
    public Estudiante buscarPorId(long id){

        return repository.findById(id).orElseThrow(() -> new RecursoNoEncontradoException("Estudiante con id: " + id + " ,no encontrado."));

    }

    //Metodo para eliminar
    public void eliminar(Long id) {
        Estudiante existente = buscarPorId(id);
        repository.delete(existente);
    }

}
