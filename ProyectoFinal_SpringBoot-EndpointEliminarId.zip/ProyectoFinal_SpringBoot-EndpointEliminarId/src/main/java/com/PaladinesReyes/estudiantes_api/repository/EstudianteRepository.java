package com.PaladinesReyes.estudiantes_api.repository;

import com.PaladinesReyes.estudiantes_api.model.Estudiante;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EstudianteRepository extends JpaRepository<Estudiante, Long> {
}

// JpaRepository<Estudiante, Long>
// dice a Spring que esta interfaz maneja la entidad Estudiante con clave primaria Long.
// y automáticamente ya tendremos métodos como
// findAll(), findById(), save(), deleteById(), etc., sin escribir SQL.