package com.PaladinesReyes.estudiantes_api.controller;

import com.PaladinesReyes.estudiantes_api.model.Estudiante;
import com.PaladinesReyes.estudiantes_api.service.EstudianteService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/estudiantes")
public class EstudianteController {

    private final EstudianteService service;

    public EstudianteController(EstudianteService service) {
        this.service = service;
    }

    //Colocaremos el endpoint para listar(leer) a todos los estudiantes que se encuentren en la base de datos
    @GetMapping
    public List<Estudiante> listar() {
        return service.listarTodos();
    }

    //Colocaremos el endpoint para crear estudiantes en la base de datos
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Estudiante crear(@Valid @RequestBody Estudiante estudiante) {
        return service.guardar(estudiante);
    }

    //Colocaremos el endpoint para buscar por id
    @GetMapping("/{id}")
    public Estudiante obtenerPorId(@PathVariable long id){
        return service.buscarPorId(id);
    }

    //Enpoint para eliminar el usuario mediante id
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }


}
