package com.PaladinesReyes.estudiantes_api.exception;

public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String message) {
        super(message);
    }
}

//Esta es una excepción personalizada que retornara un mensaje cuando busquemos un id y este
//no exista