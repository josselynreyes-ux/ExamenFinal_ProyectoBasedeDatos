package com.PaladinesReyes.estudiantes_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//Esta clase es nuestro Main
@SpringBootApplication
public class EstudiantesApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstudiantesApiApplication.class, args);
	}

}
